const CancelledReservations = () => {
  return (
    <div>
      <p>Calcelled Reservations</p>
    </div>
  );
};

export default CancelledReservations;
