import StepsOfHosting from "../components/listingHouse/StepsOfHosting";

const ListHouseOverview = () => {
  return (
    <>
      {/* 1st page */}
      <StepsOfHosting />
    </>
  );
};

export default ListHouseOverview;
